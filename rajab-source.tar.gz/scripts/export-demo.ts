import { PGlite } from "@electric-sql/pglite";
import { readFile, readdir, mkdir, writeFile } from "node:fs/promises";
import { shim, seed } from "../src/lib/seed";
import { DEMO_USERS } from "../src/lib/demo-ids";
import { contractPdf } from "../src/lib/pdf";
import type { State } from "../src/lib/types";
const db = new PGlite();
await db.waitReady;
await db.exec(shim);
for (const f of (await readdir("supabase/migrations")).sort())
  await db.exec(await readFile("supabase/migrations/" + f, "utf8"));
await seed(db);
const data = await db.transaction(async (tx) => {
  await tx.exec("set local role authenticated");
  await tx.query("select set_config('request.jwt.claim.sub',$1,true)", [
    DEMO_USERS.owner.id,
  ]);
  return (await tx.query<{ s: State }>("select app_state() as s")).rows[0].s;
});
await mkdir("docs/examples", { recursive: true });
await writeFile(
  "docs/examples/demo-contract.pdf",
  await contractPdf(data, data.contracts[0]),
);
await mkdir(".demo", { recursive: true });
await writeFile(".demo/state-for-review.json", JSON.stringify(data));
await db.close();
console.log("Demo contract exported");
