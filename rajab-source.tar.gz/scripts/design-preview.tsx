import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { readFile, writeFile } from "node:fs/promises";
import { AppRouterContext } from "next/dist/shared/lib/app-router-context.shared-runtime";
import { CRM } from "../src/components/crm";
import { DEMO_USERS, TENANT } from "../src/lib/demo-ids";
import type { State } from "../src/lib/types";
const data: State = JSON.parse(
  await readFile(".demo/state-for-review.json", "utf8"),
);
const router = {
  bfcacheId: "preview",
  back() {},
  forward() {},
  push() {},
  replace() {},
  refresh() {},
  hmrRefresh() {},
  async prefetch() {},
};
const css = (await readFile("src/app/globals.css", "utf8"))
  .replace(/^@import.*\n/, "")
  .replace(/^@custom-variant.*\n/, "");
const crm = renderToStaticMarkup(
  <AppRouterContext.Provider value={router}>
    <CRM
      initial={data}
      session={{
        user_id: DEMO_USERS.owner.id,
        tenant_id: TENANT,
        role: "owner",
        name: "Раджап · демо",
        platform_admin: false,
      }}
      path={[]}
      demo
    />
  </AppRouterContext.Provider>,
);
let home = await readFile(".demo/http-check/home.html", "utf8");
home = home
  .replace(/<script\b[^>]*>[\s\S]*?<\/script>/g, "")
  .replace(/<link\b[^>]*>/g, "");
const body = home.match(/<body[^>]*>([\s\S]*)<\/body>/)?.[1] ?? home;
const wrap = (markup: string) =>
  '<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>' +
  css +
  "</style></head><body>" +
  markup +
  '<script>document.querySelectorAll("a").forEach(a=>a.addEventListener("click",e=>{if(!a.getAttribute("href").startsWith("#"))e.preventDefault()}));document.querySelectorAll("form").forEach(f=>f.addEventListener("submit",e=>e.preventDefault()));document.querySelectorAll("button:not(.theme-toggle)").forEach(b=>b.disabled=true);document.querySelectorAll(".theme-toggle").forEach(b=>b.addEventListener("click",()=>document.documentElement.dataset.theme=document.documentElement.dataset.theme==="dark"?"light":"dark"));</script></body></html>';
const escape = (s: string) =>
  s
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
const html =
  '<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RAJAB FINANCE · Предпросмотр дизайна</title><style>body{margin:0;background:#f8faf9;font-family:Arial;color:#064e3b}header{box-sizing:border-box;display:flex;gap:12px;align-items:center;padding:12px 18px;min-height:65px;border-bottom:1px solid #d7e4dc;flex-wrap:wrap}strong{font-size:13px;margin-right:auto}small{font-size:11px;color:#758479}button{border:1px solid #cadacf;padding:9px 15px;border-radius:8px;color:#064e3b;background:white;cursor:pointer}button.active{background:#064e3b;color:white}iframe{border:0;width:100%;height:calc(100vh - 100px);display:none}iframe.active{display:block}@media(min-width:900px){iframe{height:calc(100vh - 65px)}}</style></head><body><header><strong>RAJAB FINANCE <small> · Статичные экраны дизайна</small></strong><small>Рабочая CRM находится в архиве проекта</small><button class="active" onclick="show(0)">Главная</button><button onclick="show(1)">Панель Раджапа</button></header><iframe class="active" title="Главная страница" sandbox="allow-scripts" srcdoc="' +
  escape(wrap(body)) +
  '"></iframe><iframe title="Дашборд CRM" sandbox="allow-scripts" srcdoc="' +
  escape(wrap(crm)) +
  '"></iframe><script>function show(i){document.querySelectorAll("iframe").forEach((f,n)=>f.classList.toggle("active",n===i));document.querySelectorAll("header button").forEach((b,n)=>b.classList.toggle("active",n===i))}</script></body></html>';
await writeFile("../RAJAB-FINANCE-preview.html", html);
console.log("Design preview saved");
