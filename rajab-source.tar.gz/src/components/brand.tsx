import Link from "next/link";
export function Brand({ light = false }: { light?: boolean }) {
  return (
    <Link className={"brand " + (light ? "brand-light" : "")} href="/">
      <span className="brand-mark">
        <svg
          width="24"
          height="30"
          viewBox="0 0 24 30"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M3 27V10L12 3L21 10V27M8 27V13L12 10L16 13V27M3 22H21"
            stroke="currentColor"
            strokeWidth="1.7"
          />
        </svg>
      </span>
      <span>
        RAJAB<span className="brand-sub">F I N A N C E</span>
      </span>
    </Link>
  );
}
