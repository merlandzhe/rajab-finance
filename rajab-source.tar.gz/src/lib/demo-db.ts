import { PGlite } from "@electric-sql/pglite";
import { readFile, readdir, mkdir } from "node:fs/promises";
import path from "node:path";
import { seed, shim } from "./seed";
const g = globalThis as unknown as { rajabDb?: Promise<PGlite> };
export function isDemo() {
  return process.env.DEMO_MODE === "true" && !process.env.VERCEL;
}
export function demoDb() {
  if (!isDemo()) throw new Error("Локальный деморежим выключен");
  if (!g.rajabDb)
    g.rajabDb = (async () => {
      const dir = path.join(process.cwd(), ".demo");
      await mkdir(dir, { recursive: true });
      const db = new PGlite(path.join(dir, "postgres"));
      await db.waitReady;
      await db.exec("set timezone='Europe/Moscow'");
      const exists = await db.query(
        "select to_regclass('public.organizations') as existing",
      );
      if (!(exists.rows[0] as { existing: unknown }).existing) {
        await db.transaction(async (tx) => {
          await tx.exec(shim);
          for (const f of (await readdir("supabase/migrations")).sort())
            if (f.endsWith(".sql"))
              await tx.exec(
                await readFile(path.join("supabase/migrations", f), "utf8"),
              );
        });
        await seed(db);
      }
      return db;
    })();
  return g.rajabDb;
}
export async function demoRpc<T>(
  userId: string | null,
  name: string,
  args: unknown[] = [],
): Promise<T> {
  const db = await demoDb();
  const allowed = [
    "app_state",
    "session_context",
    "app_command",
    "public_terms",
  ];
  if (!allowed.includes(name)) throw new Error("Unknown RPC");
  return db.transaction(async (tx) => {
    await tx.exec(`set local role ${userId ? "authenticated" : "anon"}`);
    await tx.query("select set_config('request.jwt.claim.sub',$1,true)", [
      userId ?? "",
    ]);
    const q = await tx.query<{ value: T }>(
      `select public.${name}(${args.map((_, i) => "$" + (i + 1)).join(",")}) as value`,
      args,
    );
    return q.rows[0].value;
  });
}
