import { NextResponse } from "next/server";
import { randomUUID, createHash } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { z } from "zod";
import { requireSession } from "@/lib/auth";
import { getState, command } from "@/lib/repository";
import { assertOrigin, fail, throttle } from "@/lib/http";
import { isDemo, demoDb } from "@/lib/demo-db";
import { serviceClient } from "@/lib/supabase";
import { validateUpload } from "@/lib/uploads";
export const runtime = "nodejs";
export async function POST(req: Request) {
  try {
    assertOrigin(req);
    const s = await requireSession();
    if (!s.tenant_id || !["owner", "manager"].includes(s.role ?? ""))
      throw new Error("FORBIDDEN");
    await throttle(req, "upload:" + s.user_id, 20);
    const len = Number(req.headers.get("content-length"));
    if (!Number.isFinite(len) || len <= 0 || len > 5 * 1024 * 1024 + 20000)
      throw new Error("BODY_TOO_LARGE");
    const form = await req.formData();
    const applicationId = z.uuid().parse(form.get("application_id"));
    const kind = z.literal("purchase_receipt").parse(form.get("kind"));
    const file = form.get("file");
    if (!(file instanceof File)) throw new Error("File required");
    const state = await getState(s);
    if (
      !state.applications.some(
        (a) =>
          a.id === applicationId &&
          a.tenant_id === s.tenant_id &&
          a.status !== "contracted",
      )
    )
      throw new Error("FORBIDDEN");
    const bytes = new Uint8Array(await file.arrayBuffer());
    const { mime, ext } = await validateUpload(bytes);
    const storagePath = `${s.tenant_id}/${applicationId}/${randomUUID()}.${ext}`;
    if (isDemo()) {
      const filePath = path.join(process.cwd(), ".demo/files", storagePath);
      await mkdir(path.dirname(filePath), { recursive: true });
      await writeFile(filePath, bytes);
      await (
        await demoDb()
      ).query("insert into storage.objects(bucket_id,name) values($1,$2)", [
        "deal-documents",
        storagePath,
      ]);
    } else {
      const { error } = await serviceClient()
        .storage.from("deal-documents")
        .upload(storagePath, bytes, { contentType: mime, upsert: false });
      if (error) throw error;
    }
    const result = await command(
      s,
      "document.register",
      {
        application_id: applicationId,
        kind,
        name:
          file.name.replace(/[^\p{L}\p{N} ._()-]/gu, "").slice(0, 170) ||
          "Документ",
        storage_path: storagePath,
        mime_type: mime,
        size_bytes: bytes.byteLength,
        sha256: createHash("sha256").update(bytes).digest("hex"),
      },
      randomUUID(),
    );
    return NextResponse.json(result);
  } catch (e) {
    return fail(e);
  }
}
