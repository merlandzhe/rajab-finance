import { NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { isDemo } from "@/lib/demo-db";
import { serviceClient } from "@/lib/supabase";
import { sendTelegram } from "@/lib/telegram";
export const runtime = "nodejs";
export const maxDuration = 60;
export async function GET(req: Request) {
  if (isDemo())
    return NextResponse.json(
      { error: "Демо: отправка отключена" },
      { status: 403 },
    );
  const token = req.headers.get("authorization") ?? "",
    expected = process.env.CRON_SECRET
      ? "Bearer " + process.env.CRON_SECRET
      : "";
  if (
    !expected ||
    Buffer.byteLength(token) !== Buffer.byteLength(expected) ||
    !timingSafeEqual(Buffer.from(token), Buffer.from(expected))
  )
    return new NextResponse("Unauthorized", { status: 401 });
  const { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, PUBLIC_TENANT_ID } =
    process.env;
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID || !PUBLIC_TENANT_ID)
    return NextResponse.json(
      { error: "Telegram не настроен" },
      { status: 503 },
    );
  const db = serviceClient();
  const reminders = await db.rpc("queue_reminders", {
    p_tenant: PUBLIC_TENANT_ID,
  });
  if (reminders.error)
    return new NextResponse("Queue unavailable", { status: 503 });
  const { data, error } = await db.rpc("claim_notifications", {
    p_tenant: PUBLIC_TENANT_ID,
  });
  if (error) return new NextResponse("Queue unavailable", { status: 503 });
  let sent = 0,
    failed = 0;
  for (const n of data ?? []) {
    try {
      await sendTelegram(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, n.message);
      const saved = await db
        .from("notifications")
        .update({
          status: "sent",
          sent_at: new Date().toISOString(),
          last_error: null,
        })
        .eq("id", n.id)
        .eq("tenant_id", PUBLIC_TENANT_ID);
      if (saved.error) throw new Error("Status unavailable");
      sent++;
    } catch {
      await db
        .from("notifications")
        .update({
          status: "failed",
          last_error: "Не удалось подтвердить доставку",
        })
        .eq("id", n.id)
        .eq("tenant_id", PUBLIC_TENANT_ID);
      failed++;
    }
  }
  return NextResponse.json(
    { sent, failed },
    { headers: { "Cache-Control": "no-store" } },
  );
}
