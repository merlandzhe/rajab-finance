import { NextResponse } from "next/server";
import { requireSession } from "@/lib/auth";
import { command } from "@/lib/repository";
import { assertOrigin, fail, limitedJson, throttle } from "@/lib/http";
import { commandEnvelope, schemas } from "@/lib/validation";
export async function POST(req: Request) {
  try {
    assertOrigin(req);
    const s = await requireSession();
    await throttle(req, "command:" + s.user_id, 100);
    const body = commandEnvelope.parse(await limitedJson(req));
    const payload = schemas[body.action].parse(body.payload);
    return NextResponse.json(await command(s, body.action, payload, body.key));
  } catch (e) {
    return fail(e);
  }
}
