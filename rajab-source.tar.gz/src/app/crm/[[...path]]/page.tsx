import { redirect } from "next/navigation";
import { session } from "@/lib/auth";
import { getState } from "@/lib/repository";
import { isDemo } from "@/lib/demo-db";
import { CRM } from "@/components/crm";
export const dynamic = "force-dynamic";
export default async function Page({
  params,
}: {
  params: Promise<{ path?: string[] }>;
}) {
  const s = await session();
  if (!s) redirect("/login");
  if (s.role === "client") redirect("/cabinet");
  const { path = [] } = await params;
  if (!s.tenant_id && !s.platform_admin) redirect("/login");
  if (s.platform_admin && !s.tenant_id && path[0] !== "platform")
    redirect("/crm/platform");
  if (s.role !== "owner" && path[0] === "settings")
    return (
      <main className="legal">
        <h1>Доступ ограничен</h1>
        <p>Тарифы настраивает владелец организации.</p>
        <a href="/crm">Вернуться</a>
      </main>
    );
  return (
    <CRM initial={await getState(s)} session={s} path={path} demo={isDemo()} />
  );
}
