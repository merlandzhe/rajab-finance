import { Brand } from "@/components/brand";
import { LoginForm } from "@/components/login-form";
import { isDemo } from "@/lib/demo-db";
import { ThemeToggle } from "@/components/theme-toggle";
export const dynamic = "force-dynamic";
export default function Page() {
  return (
    <>
      <header className="public-nav">
        <Brand />
        <ThemeToggle />
      </header>
      <main className="card login">
        <div className="login-intro">
          <p className="eyebrow">Рабочее пространство</p>
          <h1>
            Каждая сделка.
            <br />
            Под контролем.
          </h1>
          <p>
            От первого запроса до последнего платежа — в одном пространстве
            RAJAB FINANCE.
          </p>
          <span style={{ fontSize: 10, color: "#b4ccbd" }}>
            Прозрачность в деталях.
          </span>
        </div>
        <LoginForm demo={isDemo()} />
      </main>
    </>
  );
}
