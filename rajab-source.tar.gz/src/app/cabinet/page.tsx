import { redirect } from "next/navigation";
import { session } from "@/lib/auth";
import { getState } from "@/lib/repository";
import { CRM } from "@/components/crm";
import { isDemo } from "@/lib/demo-db";
export const dynamic = "force-dynamic";
export default async function Page() {
  const s = await session();
  if (!s) redirect("/login");
  if (s.role !== "client") redirect("/crm");
  return (
    <CRM
      initial={await getState(s)}
      session={s}
      path={["cabinet"]}
      demo={isDemo()}
    />
  );
}
