import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: {
    default: "RAJAB FINANCE — товарная мурабаха",
    template: "%s · RAJAB FINANCE",
  },
  description:
    "Прозрачные условия покупки конкретного товара с фиксированной ценой. Демонстрационная платформа.",
  robots: { index: false, follow: false },
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
